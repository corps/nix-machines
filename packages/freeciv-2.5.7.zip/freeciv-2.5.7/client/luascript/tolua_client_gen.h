/*
** Lua binding: client
** Generated automatically by tolua 5.2.0 on Sat May 13 13:03:36 2017.
*/

/* Exported function */
TOLUA_API int tolua_client_open (lua_State* tolua_S);
LUALIB_API int luaopen_client (lua_State* tolua_S);

